#!/bin/sh
./arithoh.sh &
./fstime.sh &
./syscall.sh &
./syscall.sh &
./fstime.sh &
wait
