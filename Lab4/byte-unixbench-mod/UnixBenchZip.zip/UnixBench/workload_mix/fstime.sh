#!/bin/sh
time ../pgms/fstime
echo "fstime completed"
echo "---"
