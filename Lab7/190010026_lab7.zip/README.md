Just run the following command to get the required files:

$ ./runme

If above command is not working then run the following 2 commands:

$ chmod 755 runme
$ ./runme
