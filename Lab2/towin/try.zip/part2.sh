cp forkexit.c /usr/src/minix/servers/pm/
cd /usr/src && ls
