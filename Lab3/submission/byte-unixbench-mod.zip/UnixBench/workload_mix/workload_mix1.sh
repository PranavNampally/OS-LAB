#!/bin/sh
./arithoh.sh & #CPU intensive
./arithoh.sh & #CPU intensive
./arithoh.sh & #CPU intensive
wait

# Works alternatively